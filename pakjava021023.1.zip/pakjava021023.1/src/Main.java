import Student.Studinfo;

public class Main {
    public static void main(String[] args) {

       int num=10;
        Studinfo student= new Studinfo();
        student.setName("Petya");//без модификатора
        student.setLastName("Pupkin");//приватный модификатор
        Studinfo clonstudent= new Studinfo(student);
        System.out.println(student==clonstudent);




    }
}