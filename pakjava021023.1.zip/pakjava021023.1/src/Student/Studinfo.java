package Student;

import java.time.LocalDate;

public class Studinfo {

    public long id;
    String name;
    private String lastName;
    public LocalDate birthday;
    public String specialization;

    public Studinfo(Studinfo original){
        this(original.name,original.lastName);
    }

    public Studinfo(String name, String lastName) {
        this.name=name;
        this.lastName=lastName;

    }

    public Studinfo() {
    }

    public String getLastName(){
        return lastName;
    }
    public void setLastName(String lastName){
        this.lastName=lastName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
