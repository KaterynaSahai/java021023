package Student;

public class University {
  public Studinfo getMathStudent(String name,String lastName){
      Studinfo student=new Studinfo(name,lastName);
      student.specialization="Math";
      return student;

      public Studinfo getGeoStudent(String name,String lastName){
          Studinfo student=new Studinfo(name,lastName);
          student.specialization="Geo";
          return student;
  }
}
